import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';    // // Link for internal navigation, useNavigate to redirect the user
import ClickOutside from '../ClickOutside';              // Component to detect clicks outside the dropdown
import { UserLogin } from '../../interfaces/Interfaces'; // UserLogin interface
import { postFetch } from '../../utils/apiMethods';      
import { getCurrentUser } from '../../utils/utils';      // Function to get de current user
import { toast } from 'react-toastify';                  // Library to display notifications

// Definition of the props that the DropdownUser component accepts
interface DropdownUserProps {
  handleLogout: () => void; // Function that is executed when the user logs out
}

// Definition of the DropdownUser component
const DropdownUser: React.FC<DropdownUserProps> = ({ handleLogout }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false); // State to control if the dropdown is open or closed
  const navigate = useNavigate();                          // Hook for programmatic navigation

  const loggedUser = getCurrentUser();                     // Gets the current user
  const currentUser = localStorage.getItem('currentUser'); // Gets the current from localStorage 
  const user = JSON.parse(currentUser ? currentUser : ''); // Convert localStorage string to JSON object

  // Function to log out the user
  const handleLogoutUser = async () => {
    const session = { idPerson: loggedUser.ID_Person, value: 0 };          // Create the session object with the necessary data
    const result = await postFetch('users-persons/user-session', session); // Make a POST request to close the session on the backend
    if (result.error) {
      return toast.error("Tienes una sesion activa en otro dispositivo", {
        autoClose: 3000,
        theme: "dark"
      })
    }
    handleLogout();     // Execute the function passed by props to close the session
    navigate('/login'); // Redirect the user to the login page
  };

  // Function to get the user's role based on their ID
  const role = (user: UserLogin) => {
    if (user.ID_Role === 1) return 'Super Administrador';
    else if (user.ID_Role === 2) return 'Gerencia';
    else if (user.ID_Role === 3) return 'Administrador';
    else if (user.ID_Role === 4) return 'Mayorista';
    else if (user.ID_Role === 5) return 'Instalador';
    else if (user.ID_Role === 6) return 'Autorizado';
  };

  return (
    <ClickOutside onClick={() => setDropdownOpen(false)} className="relative">
      
      {/* Component that opens/closes the dropdown */}
      <Link
        onClick={() => setDropdownOpen(!dropdownOpen)}
        className="flex items-center gap-4"
        to="#"
      >
        <span className="hidden text-right lg:block">
          <span className="block text-sm font-medium text-black dark:text-white">
            {user.Username}
          </span>
          <span className="block text-xs">
            { role(user) }
          </span>
        </span>
        <svg
          className="hidden fill-current sm:block"
          width="12"
          height="8"
          viewBox="0 0 12 8"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M0.410765 0.910734C0.736202 0.585297 1.26384 0.585297 1.58928 0.910734L6.00002 5.32148L10.4108 0.910734C10.7362 0.585297 11.2638 0.585297 11.5893 0.910734C11.9147 1.23617 11.9147 1.76381 11.5893 2.08924L6.58928 7.08924C6.26384 7.41468 5.7362 7.41468 5.41077 7.08924L0.410765 2.08924C0.0853277 1.76381 0.0853277 1.23617 0.410765 0.910734Z"
            fill=""
          />
        </svg>
      </Link>

      {/* <!-- Dropdown Start --> */}
      {dropdownOpen && (
        <div
          className={`absolute right-0 mt-4 flex w-62.5 flex-col rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark`}
        >

          {/* Dropdown options */}
          <ul className="flex flex-col gap-5 border-b border-stroke px-6 py-7.5 dark:border-strokedark">
            <li>
              <Link
                to="/reset-password"
                className="flex items-center gap-3.5 text-sm font-medium duration-300 ease-in-out hover:text-primary lg:text-base"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 1 1-3 0m3 0a1.5 1.5 0 1 0-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m-9.75 0h9.75" />
                </svg>

                Cambiar contraseña
              </Link>
            </li>
          </ul>

          {/* Logout button */}
          <button
            onClick={handleLogoutUser}
            className="flex items-center gap-3.5 px-6 py-4 text-sm font-medium duration-300 ease-in-out hover:text-primary lg:text-base">
            <svg
              className="fill-current"
              width="22"
              height="22"
              viewBox="0 0 22 22"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M15.5375 0.618744H11.6531C10.7594 0.618744 10.0031 1.37499 10.0031 2.26874V4.64062C10.0031 5.05312 10.3469 5.39687 10.7594 5.39687C11.1719 5.39687 11.55 5.05312 11.55 4.64062V2.23437C11.55 2.16562 11.5844 2.13124 11.6531 2.13124H15.5375C16.3625 2.13124 17.0156 2.78437 17.0156 3.60937V18.3562C17.0156 19.1812 16.3625 19.8344 15.5375 19.8344H11.6531C11.5844 19.8344 11.55 19.8 11.55 19.7312V17.3594C11.55 16.9469 11.2062 16.6031 10.7594 16.6031C10.3125 16.6031 10.0031 16.9469 10.0031 17.3594V19.7312C10.0031 20.625 10.7594 21.3812 11.6531 21.3812H15.5375C17.2219 21.3812 18.5625 20.0062 18.5625 18.3562V3.64374C18.5625 1.95937 17.1875 0.618744 15.5375 0.618744Z"
                fill=""
              />
              <path
                d="M6.05001 11.7563H12.2031C12.6156 11.7563 12.9594 11.4125 12.9594 11C12.9594 10.5875 12.6156 10.2438 12.2031 10.2438H6.08439L8.21564 8.07813C8.52501 7.76875 8.52501 7.2875 8.21564 6.97812C7.90626 6.66875 7.42501 6.66875 7.11564 6.97812L3.67814 10.4844C3.36876 10.7938 3.36876 11.275 3.67814 11.5844L7.11564 15.0906C7.25314 15.2281 7.45939 15.3312 7.66564 15.3312C7.87189 15.3312 8.04376 15.2625 8.21564 15.125C8.52501 14.8156 8.52501 14.3344 8.21564 14.025L6.05001 11.7563Z"
                fill=""
              />
            </svg>
            Salir
          </button>
        </div>
      )}

      {/* <!-- Dropdown End --> */}
    </ClickOutside>
  );
};

// Export the component
export default DropdownUser;
